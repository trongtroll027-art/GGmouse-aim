package com.example.ffaimbubble

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

class BubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var bubbleView: View
    private var aimEnabled = false
    private var running = true
    private var targetPkg: String = ""

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var screenW = 0
    private var screenH = 0

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, buildNotif("Đang chạy aim bubble..."))
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        targetPkg = intent?.getStringExtra("target_pkg") ?: ""
        createBubble()
        if (targetPkg.isNotEmpty()) {
            packageManager.getLaunchIntentForPackage(targetPkg)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(it)
            }
        }
        startProjectionRequest()
        startAimLoop()
        return START_STICKY
    }

    private fun createBubble() {
        val size = 130
        val iv = TextView(this).apply {
            text = "◎"
            textSize = 40f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#CC111111"))
        }
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 50; params.y = 300
        windowManager.addView(iv, params)
        bubbleView = iv

        iv.setOnTouchListener(object : View.OnTouchListener {
            var initX = 0; var initY = 0
            var touchX = 0f; var touchY = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initX = params.x; initY = params.y
                        touchX = e.rawX; touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                        params.x = initX + dx
                        params.y = initY + dy
                        windowManager.updateViewLayout(iv, params)
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) showMenu()
                    }
                }
                return true
            }
        })
    }

    private fun showMenu() {
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#EE000000"))
            setPadding(30, 30, 30, 30)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.CENTER

        fun addButton(text: String, onClick: () -> Unit) {
            val b = TextView(this).apply {
                this.text = text
                setTextColor(Color.WHITE)
                textSize = 18f
                setPadding(20, 20, 20, 20)
                setOnClickListener { onClick() }
            }
            menu.addView(b)
        }

        addButton("Aimlock: ${if (aimEnabled) "BẬT" else "TẮT"}") {
            aimEnabled = !aimEnabled
            windowManager.removeView(menu)
            showMenu()
        }
        addButton("Thoát") {
            windowManager.removeView(menu)
            stopSelf()
        }

        windowManager.addView(menu, params)
    }

    private fun startProjectionRequest() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = mpm.createScreenCaptureIntent()
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Quyền này cần được cấp qua Activity. Trong bản rút gọn, giả định đã có.
    }

    private fun startAimLoop() {
        thread {
            while (running) {
                try {
                    if (aimEnabled) {
                        val dx = detectEnemyOffsetX()
                        val dy = detectEnemyOffsetY()
                        if (dx != 0f || dy != 0f) {
                            Handler(Looper.getMainLooper()).post {
                                AimAccessibilityService.instance?.dragAim(dx, dy)
                            }
                        }
                    }
                } catch (_: Throwable) {}
                Thread.sleep(25)
            }
        }
    }

    private fun detectEnemyOffsetX(): Float {
        val img = imageReader?.acquireLatestImage() ?: return 0f
        try {
            val plane = img.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            var sumX = 0L; var count = 0
            for (y in 0 until screenH step 8) {
                for (x in 0 until screenW step 8) {
                    val idx = y * rowStride + x * pixelStride
                    if (idx + 3 >= buf.limit()) continue
                    val r = buf.get(idx).toInt() and 0xFF
                    val g = buf.get(idx + 1).toInt() and 0xFF
                    val b = buf.get(idx + 2).toInt() and 0xFF
                    if (r > 170 && g < 90 && b < 90) { sumX += x; count++ }
                }
            }
            if (count < 5) return 0f
            val avgX = sumX / count
            return (avgX - screenW / 2f) * 0.05f
        } finally { img.close() }
    }

    private fun detectEnemyOffsetY(): Float {
        val img = imageReader?.acquireLatestImage() ?: return 0f
        try {
            val plane = img.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            var sumY = 0L; var count = 0
            for (y in 0 until screenH step 8) {
                for (x in 0 until screenW step 8) {
                    val idx = y * rowStride + x * pixelStride
                    if (idx + 3 >= buf.limit()) continue
                    val r = buf.get(idx).toInt() and 0xFF
                    val g = buf.get(idx + 1).toInt() and 0xFF
                    val b = buf.get(idx + 2).toInt() and 0xFF
                    if (r > 170 && g < 90 && b < 90) { sumY += y; count++ }
                }
            }
            if (count < 5) return 0f
            val avgY = sumY / count
            return (avgY - screenH / 2f) * 0.05f - 6f
        } finally { img.close() }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("bubble", "Bubble",
                NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotif(text: String): Notification =
        NotificationCompat.Builder(this, "bubble")
            .setContentTitle("FF Aim Bubble").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true).build()

    override fun onDestroy() {
        super.onDestroy()
        running = false
        try { windowManager.removeView(bubbleView) } catch (_: Throwable) {}
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
    }
}