package com.example.ffaimbubble

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var adapter: AppAdapter
    private val selected = mutableSetOf<String>()

    private val onBinderReceived = Shizuku.OnBinderReceivedListener {
        runOnUiThread {
            tvStatus.text = "Shizuku đã ghép nối. Vui lòng cấp quyền."
            Shizuku.requestPermission(0)
        }
    }
    private val onBinderDead = Shizuku.OnBinderDeadListener {
        runOnUiThread { tvStatus.text = "Shizuku đã ngắt kết nối." }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        val rv = findViewById<RecyclerView>(R.id.rvApps)
        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnOverlay = findViewById<Button>(R.id.btnOverlay)
        val btnAcc = findViewById<Button>(R.id.btnAcc)

        adapter = AppAdapter(selected) { _, _ -> }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter
        loadApps()

        btnOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Đã có quyền overlay", Toast.LENGTH_SHORT).show()
        }

        btnAcc.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnStart.setOnClickListener {
            if (selected.isEmpty()) {
                Toast.makeText(this, "Chưa chọn app nào", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val target = selected.first()
            val i = Intent(this, BubbleService::class.java)
            i.putExtra("target_pkg", target)
            startForegroundService(i)
            Toast.makeText(this, "Đang khởi động bubble...", Toast.LENGTH_SHORT).show()
            moveTaskToBack(true)
        }

        Shizuku.addBinderReceivedListenerSticky(onBinderReceived)
        Shizuku.addBinderDeadListener(onBinderDead)

        if (Shizuku.pingBinder()) {
            tvStatus.text = "Shizuku đã sẵn sàng."
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(0)
            }
        } else {
            tvStatus.text = "Shizuku chưa chạy. Hãy mở Shizuku và kích hoạt."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == 0 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            tvStatus.text = "Đã cấp quyền Shizuku."
        } else {
            tvStatus.text = "Từ chối cấp quyền Shizuku."
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    private fun loadApps() {
        val pm = packageManager
        val list = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
        adapter.submit(list)
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(onBinderReceived)
        Shizuku.removeBinderDeadListener(onBinderDead)
    }
}